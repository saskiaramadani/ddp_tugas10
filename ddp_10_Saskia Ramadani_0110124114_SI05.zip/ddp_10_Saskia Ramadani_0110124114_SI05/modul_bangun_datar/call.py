import main

print('## Perhitungan Persegi ##')
main.l_persegi(10)

print('## perhitungan persegi panjang ##')
main.panjang_persegi(5,4)

print('## Perhitungan Luas Persegi ##')
main.l_segitiga(5,2)

print('## perhitungan lingkaran ##')
main.l_lingkaran(10,4)

print('## perhitungan jajar genjang ##')
main.l_j_genjang(20,2)