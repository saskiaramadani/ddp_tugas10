import main

print('## Perhitungan kubus ##')
main.l_kubus(6)

print('## perhitungan balok ##')
main.l_balok(8,4,2)

print('## Perhitungan tabung ##')
main.l_tabung(15,3)

print('## perhitungan limas ##')
main.l_limas(10,4)

print('## perhitungan prisma ##')
main.l_prisma(6,3)