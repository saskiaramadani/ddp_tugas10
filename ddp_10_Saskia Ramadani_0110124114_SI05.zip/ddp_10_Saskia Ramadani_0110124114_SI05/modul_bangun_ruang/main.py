import math 

def l_kubus(sisi):
    luas = 6 * (sisi * sisi)
    print(f'Luas kubus adalah{luas}')

def l_balok(p, l, t):
    luas= 2 * (p*1)+(p*t)+(l*t)
    print(f'Luas balok adalah{luas}')

def l_tabung(r2, t):
    luas = 6 * (r2, + t)
    print(f'Luas tabung adalah{luas}')

def l_limas(a, st):
    luas = math.sqrt(3) * a * st
    print(f'Luas limas adalah{luas}')
    
def l_prisma(alas, tinggi):
    luas = 1/2 * alas * tinggi
    print(f'luas perisma adalah{luas}')